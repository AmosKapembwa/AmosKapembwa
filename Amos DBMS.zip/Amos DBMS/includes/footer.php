<footer class="footer mt-auto py-3 bg-light">
    <div class="container">
        <span class="text-muted">&copy; 2024 Citizen Participation Platform</span>
    </div>
</footer>
