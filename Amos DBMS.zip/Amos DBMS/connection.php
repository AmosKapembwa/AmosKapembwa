<?php

$server = "localhost";
$username = "root";
$password = "";
$db = "abc";

$conn = new mysqli($server, $username, $password, $db);

?>